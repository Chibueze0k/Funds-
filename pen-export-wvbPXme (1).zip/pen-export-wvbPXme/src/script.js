// Get the login button and login message elements

const loginButton = document.getElementById('login-button');

const loginMessage = document.getElementById('login-message');

const passwordInput = document.getElementById('password');

// Add an event listener for the login button click event

loginButton.addEventListener('click', (e) => {

  e.preventDefault();

  const password = passwordInput.value;

  // Check if the password is correct

  if (password === 'asdfghjkl') {

    loginMessage.textContent = 'Successful login!';

    // Redirect to the dashboard page

    window.location.href = '#dashboard';

  } else {

    loginMessage.textContent = 'Incorrect password';

  }

});

// Get the dashboard elements

const dashboard = document.getElementById('dashboard');

const withdrawButton = document.getElementById('withdraw-btn');

const addFundsButton = document.getElementById('add-funds-btn');

const balanceElement = document.getElementById('balance');

const withdrawInfoElement = document.getElementById('withdraw-info');

const addFundsInfoElement = document.getElementById('add-funds-info');

// Add an event listener for the withdraw button click event

withdrawButton.addEventListener('click', () => {

  withdrawInfoElement.setAttribute('aria-hidden', 'false');

});

// Add an event listener for the add funds button click event

addFundsButton.addEventListener('click', () => {

  addFundsInfoElement.setAttribute('aria-hidden', 'false');

});

// Add an event listener for the withdraw submit button click event

document.getElementById('withdraw-submit').addEventListener('click', (e) => {

  e.preventDefault();

  const bankName = document.getElementById('bank-name').value;

  const accountNumber = document.getElementById('account-number').value;

  const swiftCode = document.getElementById('swift-code').value;

  const amount = document.getElementById('amount').value;

  // Perform withdrawal logic here

  console.log(`Withdrawal successful! Bank Name: ${bankName}, Account Number: ${accountNumber}, Swift Code: ${swiftCode}, Amount: ${amount}`);

  withdrawInfoElement.setAttribute('aria-hidden', 'true');

});

// Add an event listener for the add funds submit button click event

document.getElementById('add-funds-submit').addEventListener('click', (e) => {

  e.preventDefault();

  const addAmount = document.getElementById('add-amount').value;

  // Perform add funds logic here

  console.log(`Add funds successful! Amount: ${addAmount}`);

  addFundsInfoElement.setAttribute('aria-hidden', 'true');

  balanceElement.textContent = `Balance: N${parseInt(balanceElement.textContent.split(' ')[1]) + parseInt(addAmount)}`;

});